/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package eny.vero;

import java.sql.*;

/**
 *
 * @author eny
 */
public class conexaoBanco {
        private static final String URL = "jdbc:mysql://localhost/veroDB";
        private static final String USUARIO = "root";
        private static final String SENHA = "316497a.i";
        public static Connection obterConexao() throws SQLException{
            return DriverManager.getConnection(URL, USUARIO, SENHA);
        }
    
}