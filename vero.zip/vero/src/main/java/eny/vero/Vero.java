/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package eny.vero;

import view.telaLogin;

/**
 *
 * @author sherl
 */
public class Vero {

    public static void main(String[] args) {
        java.awt.EventQueue.invokeLater(() -> new telaLogin().setVisible(true));
    }
}
